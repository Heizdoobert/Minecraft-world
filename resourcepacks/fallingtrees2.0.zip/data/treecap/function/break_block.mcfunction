setblock ~ ~ ~ air destroy

# 1. Search for connected logs to break
execute positioned ~ ~1 ~ if block ~ ~ ~ #minecraft:logs run function treecap:break_block
execute positioned ~1 ~ ~ if block ~ ~ ~ #minecraft:logs run function treecap:break_block
execute positioned ~-1 ~ ~ if block ~ ~ ~ #minecraft:logs run function treecap:break_block
execute positioned ~ ~ ~1 if block ~ ~ ~ #minecraft:logs run function treecap:break_block
execute positioned ~ ~ ~-1 if block ~ ~ ~ #minecraft:logs run function treecap:break_block

# 2. Check diagonals going upwards to catch branching trees
execute positioned ~1 ~1 ~ if block ~ ~ ~ #minecraft:logs run function treecap:break_block
execute positioned ~-1 ~1 ~ if block ~ ~ ~ #minecraft:logs run function treecap:break_block
execute positioned ~ ~1 ~1 if block ~ ~ ~ #minecraft:logs run function treecap:break_block
execute positioned ~ ~1 ~-1 if block ~ ~ ~ #minecraft:logs run function treecap:break_block

# 3. Trigger leaf breaking for leaves touching the logs
execute positioned ~ ~1 ~ if block ~ ~ ~ #minecraft:leaves run function treecap:break_leaves
execute positioned ~1 ~ ~ if block ~ ~ ~ #minecraft:leaves run function treecap:break_leaves
execute positioned ~-1 ~ ~ if block ~ ~ ~ #minecraft:leaves run function treecap:break_leaves
execute positioned ~ ~ ~1 if block ~ ~ ~ #minecraft:leaves run function treecap:break_leaves
execute positioned ~ ~ ~-1 if block ~ ~ ~ #minecraft:leaves run function treecap:break_leaves