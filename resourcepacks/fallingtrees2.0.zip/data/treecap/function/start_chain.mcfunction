execute positioned ~ ~1 ~ if block ~ ~ ~ #minecraft:logs run function treecap:break_block
execute positioned ~1 ~ ~ if block ~ ~ ~ #minecraft:logs run function treecap:break_block
execute positioned ~-1 ~ ~ if block ~ ~ ~ #minecraft:logs run function treecap:break_block
execute positioned ~ ~ ~1 if block ~ ~ ~ #minecraft:logs run function treecap:break_block
execute positioned ~ ~ ~-1 if block ~ ~ ~ #minecraft:logs run function treecap:break_block