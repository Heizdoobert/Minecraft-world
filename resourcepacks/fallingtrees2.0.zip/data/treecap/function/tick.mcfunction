# Check if an axe was used AND the player is currently sneaking (predicate=treecap:is_sneaking)
execute as @a[scores={axe_wood=1..},predicate=treecap:is_sneaking] at @s as @e[type=item,distance=..6,nbt={Age:0s}] at @s run function treecap:start_chain
execute as @a[scores={axe_stone=1..},predicate=treecap:is_sneaking] at @s as @e[type=item,distance=..6,nbt={Age:0s}] at @s run function treecap:start_chain
execute as @a[scores={axe_iron=1..},predicate=treecap:is_sneaking] at @s as @e[type=item,distance=..6,nbt={Age:0s}] at @s run function treecap:start_chain
execute as @a[scores={axe_gold=1..},predicate=treecap:is_sneaking] at @s as @e[type=item,distance=..6,nbt={Age:0s}] at @s run function treecap:start_chain
execute as @a[scores={axe_diamond=1..},predicate=treecap:is_sneaking] at @s as @e[type=item,distance=..6,nbt={Age:0s}] at @s run function treecap:start_chain
execute as @a[scores={axe_netherite=1..},predicate=treecap:is_sneaking] at @s as @e[type=item,distance=..6,nbt={Age:0s}] at @s run function treecap:start_chain

# Reset all trackers for everyone so normal chopping still works fine
scoreboard players reset @a axe_wood
scoreboard players reset @a axe_stone
scoreboard players reset @a axe_iron
scoreboard players reset @a axe_gold
scoreboard players reset @a axe_diamond
scoreboard players reset @a axe_netherite