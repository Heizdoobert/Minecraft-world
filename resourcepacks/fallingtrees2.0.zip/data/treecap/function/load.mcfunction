# Create a separate tracker for every axe type
scoreboard objectives add axe_wood used:wooden_axe
scoreboard objectives add axe_stone used:stone_axe
scoreboard objectives add axe_iron used:iron_axe
scoreboard objectives add axe_gold used:golden_axe
scoreboard objectives add axe_diamond used:diamond_axe
scoreboard objectives add axe_netherite used:netherite_axe