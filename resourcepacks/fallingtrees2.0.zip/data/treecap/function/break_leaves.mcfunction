setblock ~ ~ ~ air destroy

# Recursively search for and break connected leaves in all 6 directions
execute positioned ~ ~1 ~ if block ~ ~ ~ #minecraft:leaves run function treecap:break_leaves
execute positioned ~ ~-1 ~ if block ~ ~ ~ #minecraft:leaves run function treecap:break_leaves
execute positioned ~1 ~ ~ if block ~ ~ ~ #minecraft:leaves run function treecap:break_leaves
execute positioned ~-1 ~ ~ if block ~ ~ ~ #minecraft:leaves run function treecap:break_leaves
execute positioned ~ ~ ~1 if block ~ ~ ~ #minecraft:leaves run function treecap:break_leaves
execute positioned ~ ~ ~-1 if block ~ ~ ~ #minecraft:leaves run function treecap:break_leaves